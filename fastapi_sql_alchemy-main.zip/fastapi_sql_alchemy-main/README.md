# fastapi_sql_alchemy
FastAPI alchemy postgresql
